# Minimalist Docker Environment for Laravel + Vue 3

Proyek ini menyediakan lingkungan Docker yang ringan dan minimalis yang dikhususkan untuk pengembangan **Laravel 10/11** dan **Vue 3** (menggunakan Vite). Lingkungan ini sangat cocok dijalankan melalui **WSL (Ubuntu)** di Windows.

## 📦 Apa yang Termasuk di Dalamnya?
- **PHP 8.2 FPM**: Dilengkapi dengan Composer, ekstensi standar Laravel, serta Node.js & NPM bawaan untuk kompilasi _frontend_ Vue.
- **Nginx**: Web server terkonfigurasi pada port `8000`.
- **MySQL 8.0**: Database server siap pakai.

## 🚀 Cara Menggunakan (Panduan WSL)

1. Buka terminal WSL Anda dan arahkan ke folder ini.
2. Jalankan container dengan perintah berikut:
   ```bash
   docker compose up -d --build
   ```

### Jika Belum Ada Kode Laravel (Install Baru)

Jalankan perintah ini untuk mengunduh framework Laravel ke dalam folder `src/`:
```bash
docker compose exec app composer create-project laravel/laravel .
```

Berikan hak akses _read/write_ ke folder `storage` agar aplikasi tidak *error*:
```bash
docker compose exec app chmod -R 777 storage bootstrap/cache
```

### Menginstal Vue 3 & Menjalankan Vite

Setelah Laravel terinstal, Anda bisa menginstal _dependencies_ Node:
```bash
docker compose exec app npm install
docker compose exec app npm install vue
```
_(Pastikan Anda juga menyesuaikan konfigurasi `vite.config.js` dan file `app.js` Anda agar menggunakan Vue)._

Untuk menjalankan server pengembangan frontend (Vite) yang otomatis _hot-reload_:
```bash
docker compose exec app npm run dev
```
Port `5173` sudah dibuka sehingga _Hot Module Replacement_ (HMR) akan otomatis terhubung ke sistem operasi utama (Windows) Anda.

## 🌐 Akses Aplikasi
- **Aplikasi Web**: [http://localhost:8000](http://localhost:8000)
- **Kredensial Database**: 
  - Host: `127.0.0.1` (atau `localhost` jika menggunakan klien db di Windows)
  - Port: `3306`
  - Database: `laravel`
  - Username: `laravel`
  - Password: `root`

## 🧹 Menghentikan Container
Jika Anda ingin menghentikan container untuk sementara waktu, jalankan:
```bash
docker compose stop
```
Jika Anda ingin mematikan container dan menghapusnya (data database di dalam volume tetap aman):
```bash
docker compose down
```
