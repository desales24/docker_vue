# Laravel + Vue + Docker Setup (Laravel 13 Ready)

Lingkungan pengembangan Docker ini sudah dikonfigurasi secara optimal untuk proyek Laravel terbaru (Laravel 13) dan Vue (menggunakan Vite).

## ✨ Keunggulan Konfigurasi Ini
- **PHP 8.4**: Versi terbaru yang optimal dan direkomendasikan untuk Laravel 13.
- **Node.js 22 & npm**: Terinstall langsung dari repositori NodeSource untuk kompilasi *frontend* (Vue/Vite) yang mutakhir.
- **MySQL 8.4 LTS**: Database *Long-Term Support* yang handal.
- **Bebas Bentrok Permission**: Container secara cerdas dikunci ke `user: 1000:1000` dan PHP-FPM di-set untuk mengizinkan eksekusi non-root. Anda bebas menggunakan perintah `sudo` (root) atau akun user biasa di komputer Anda tanpa khawatir *error Permission Denied* pada file `vendor`, `log`, atau `cache`.

---

## 🚀 Cara Menjalankan

> **⚠️ PERHATIAN PENTING (ATURAN FOLDER SRC):**
> Sebelum menjalankan perintah Docker di bawah, pastikan folder `src/` **sudah ada** (dibuat secara manual oleh Anda). Jika folder `src/` belum ada, Docker akan berinisiatif membuatkannya namun dengan hak akses administrator (`root`). Akibatnya, Anda akan mendapat error *Permission Denied* saat meng-install Laravel nantinya. *(Catatan: File ZIP template ini sudah menyertakan folder `src/` kosong secara default untuk mencegah hal tersebut).*

1. **Nyalakan Container (Build Awal)**
   Jalankan perintah ini di terminal komputer Anda (host) untuk membangun *image* dan menjalankan server:
   ```bash
   docker compose up -d --build
   ```

2. **Masuk ke Dalam Bash Container**
   Agar file-file kode tetap aman, jalankan semua perintah `composer`, `npm`, atau `php artisan` dari **dalam container**. Cara masuknya:
   ```bash
   docker compose exec app bash
   ```
   *(Anda akan melihat awalan terminal berubah menjadi direktori `/var/www/html`)*.

3. **Install Framework Laravel**
   Saat Anda **sudah berada di dalam bash container**, jalankan:
   ```bash
   composer create-project laravel/laravel .
   ```
   *(Catatan: jika muncul pesan folder tidak kosong, jalankan trik ini: `composer create-project laravel/laravel tmp && mv tmp/* tmp/.* . 2>/dev/null; rm -rf tmp`)*

4. **Atur Permission Folder Standar Laravel**
   Meskipun konfigurasi kita sudah bebas bentrok antara host dan container, Laravel secara internal tetap membutuhkan jaminan akses *write* (tulis) penuh pada dua folder utamanya. Masih di dalam bash container, jalankan:
   ```bash
   chmod -R 775 storage bootstrap/cache
   ```

---

## 🔍 Cara Mengecek Versi (PHP, Node, dll)

Jika Anda ingin memastikan versi software yang terpasang, berikut adalah caranya:

**1. Cek Versi PHP, Node, NPM, dan Composer**
Masuk terlebih dahulu ke dalam bash container:
```bash
docker compose exec app bash
```
Lalu, Anda bebas menjalankan perintah-perintah cek versi standar ini:
- Versi PHP: `php -v`
- Versi Node: `node -v`
- Versi NPM: `npm -v`
- Versi Composer: `composer -V`

**2. Cek Versi Nginx**
Karena Nginx berjalan di containernya sendiri (service `web`), cara tercepat untuk mengecek versinya adalah langsung dari terminal host Anda dengan mengetik:
```bash
docker compose exec web nginx -v
```

---

## 💻 Mengakses Aplikasi
Setelah Laravel berhasil di-install, Anda bisa melihat hasilnya di browser melalui:
- **Website Utama**: [http://localhost:8000](http://localhost:8000)
- **HMR (Hot Module Replacement) Vue**: Port `5173` sudah dibuka untuk sinkronisasi otomatis UI Anda.
